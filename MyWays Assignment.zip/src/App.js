import React from "react";
import Top from "./components/top";
import Middle from "./components/middle";
import Bottom from "./components/bottom";
import "./styles.css";

function App() {
  return (
    <div className="App">
      <Top />
      <Middle />
      <Bottom />
    </div>
  );
}

export default App;
