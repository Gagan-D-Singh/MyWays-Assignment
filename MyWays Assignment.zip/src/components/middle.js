import React from "react";
import Breezy from "../images/breezy.png";
import Cloud from "../images/clouds.png";
import PartlyCloud from "../images/partly-cloudy.png";
import Data from "../weather.json";

function middle() {
  return (
    <div className="middle-parent-p">
      <h1 className="middle-heading">
        Today's forecast for New-York City, NY, United States{" "}
      </h1>
      <div className="middle-parent">
        <div className="middle-card">
          <div className="dox">
            {Object.values(Data).map((items) => {
              return (
                <div className="box" key={items.count}>
                  <h1>{items.results.channel.item.forecast[0].date}</h1>
                </div>
              );
            })}
          </div>
          <div className="box">
            {Object.values(Data).map((items) => {
              return (
                <div className="box" key={items.count}>
                  <h2>{items.results.channel.item.forecast[0].code} °C</h2>
                </div>
              );
            })}
          </div>
          <img src={Breezy} width="60px" alt="sun"></img>
          <div className="box">
            {Object.values(Data).map((items) => {
              return (
                <div className="box" key={items.count}>
                  <h3>{items.results.channel.item.forecast[0].text} °C</h3>
                </div>
              );
            })}
          </div>
        </div>
        <br />
        <br />

        <div className="middle-card">
          <div className="dox">
            {Object.values(Data).map((items) => {
              return (
                <div className="box" key={items.count}>
                  <h1>{items.results.channel.item.forecast[1].date}</h1>
                </div>
              );
            })}
          </div>
          <div className="box">
            {Object.values(Data).map((items) => {
              return (
                <div className="box" key={items.count}>
                  <h2>{items.results.channel.item.forecast[1].code} °C</h2>
                </div>
              );
            })}
          </div>
          <img src={PartlyCloud} width="60px" alt="sun"></img>
          <div className="box">
            {Object.values(Data).map((items) => {
              return (
                <div className="box" key={items.count}>
                  <h3>{items.results.channel.item.forecast[1].text} °C</h3>
                </div>
              );
            })}
          </div>
        </div>
        <br />
        <br />

        <div className="middle-card">
          <div className="dox">
            {Object.values(Data).map((items) => {
              return (
                <div className="box" key={items.count}>
                  <h1>{items.results.channel.item.forecast[2].date}</h1>
                </div>
              );
            })}
          </div>
          <div className="box">
            {Object.values(Data).map((items) => {
              return (
                <div className="box" key={items.count}>
                  <h2>{items.results.channel.item.forecast[2].code} °C</h2>
                </div>
              );
            })}
          </div>
          <img src={Cloud} width="60px" alt="sun"></img>
          <div className="box">
            {Object.values(Data).map((items) => {
              return (
                <div className="box" key={items.count}>
                  <h3>{items.results.channel.item.forecast[2].text} °C</h3>
                </div>
              );
            })}
          </div>
        </div>
        <br />
        <br />

        <div className="middle-card">
          <div className="dox">
            {Object.values(Data).map((items) => {
              return (
                <div className="box" key={items.count}>
                  <h1>{items.results.channel.item.forecast[3].date}</h1>
                </div>
              );
            })}
          </div>
          <div className="box">
            {Object.values(Data).map((items) => {
              return (
                <div className="box" key={items.count}>
                  <h2>{items.results.channel.item.forecast[3].code} °C</h2>
                </div>
              );
            })}
          </div>
          <img src={Cloud} width="60px" alt="sun"></img>
          <div className="box">
            {Object.values(Data).map((items) => {
              return (
                <div className="box" key={items.count}>
                  <h3>{items.results.channel.item.forecast[3].text} °C</h3>
                </div>
              );
            })}
          </div>
        </div>
        <br />
        <br />
      </div>

      <button className="button-33"> Next Days</button>
    </div>
  );
}

export default middle;
