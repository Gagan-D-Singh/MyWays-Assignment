import React, { useState } from "react";

function middleCard() {
  return (
    <div className="middle-card">
      <h3>morning</h3>
      <p>temperature</p>
      <img src="images/sun.jpg" alt="sun"></img>
      <p>precipitation</p>
    </div>
  );
}

export default middleCard;
