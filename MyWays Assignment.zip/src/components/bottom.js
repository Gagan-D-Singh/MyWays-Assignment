import React from "react";
import Data from "../weather.json";

function bottom() {
  return (
    <div className="bottom-parent">
      <h1> Weather Today in New-York City, NY, United States </h1>
      <p className="bottom-head">
        <div>
          {Object.values(Data).map((items) => {
            return (
              <div className="box" key={items.count}>
                <h1>
                  {items.results.channel.item.forecast[0].code} °C{" "}
                  <span className="bottom-desc">Feels Like</span>
                </h1>
              </div>
            );
          })}
        </div>
      </p>
      <div className="bottomCard">
        <div className="bottomCardLeft">
          <p>
            {" "}
            Day/Night&nbsp; &nbsp; &nbsp; -&nbsp; &nbsp; &nbsp; &nbsp;
            <div className="dox">
              {Object.values(Data).map((items) => {
                return (
                  <div className="box" key={items.count}>
                    <p>{items.results.channel.item.forecast[0].high}</p>
                  </div>
                );
              })}
            </div>{" "}
            °C /
            <div className="dox">
              {Object.values(Data).map((items) => {
                return (
                  <div className="box" key={items.count}>
                    <p>{items.results.channel.item.forecast[0].low}</p>
                  </div>
                );
              })}
            </div>{" "}
            °C
          </p>
          <p>
            Humidity &nbsp; &nbsp; &nbsp; - &nbsp; &nbsp; &nbsp;
            <div className="dox">
              {Object.values(Data).map((items) => {
                return (
                  <div className="box" key={items.count}>
                    <p>{items.results.channel.atmosphere.humidity}%</p>
                  </div>
                );
              })}
            </div>
          </p>
          <p>
            Pressure &nbsp; &nbsp; &nbsp; - &nbsp; &nbsp; &nbsp;
            <div className="dox">
              {Object.values(Data).map((items) => {
                return (
                  <div className="box" key={items.count}>
                    <p>{items.results.channel.atmosphere.pressure} mb</p>
                  </div>
                );
              })}
            </div>
          </p>
          <p>
            Visibility &nbsp; &nbsp; &nbsp; &nbsp; - &nbsp; &nbsp; &nbsp;
            <div className="dox">
              {Object.values(Data).map((items) => {
                return (
                  <div className="box" key={items.count}>
                    <p>{items.results.channel.atmosphere.visibility}%</p>
                  </div>
                );
              })}
            </div>
          </p>
        </div>
        <div className="bottomCardRight">
          <p>
            Wind &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; - &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp; &nbsp;
            <div className="dox">
              {Object.values(Data).map((items) => {
                return (
                  <div className="box" key={items.count}>
                    <p>{items.results.channel.wind.speed} km/h</p>
                  </div>
                );
              })}
            </div>
          </p>
          <p>
            Dew Point &nbsp; &nbsp; &nbsp; - &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            <div className="dox">
              {Object.values(Data).map((items) => {
                return (
                  <div className="box" key={items.count}>
                    <p>{items.results.channel.atmosphere.humidity}°</p>
                  </div>
                );
              })}
            </div>
          </p>
          <p>
            UV Index &nbsp; &nbsp; &nbsp; &nbsp; - &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp;
            <div className="dox">
              {Object.values(Data).map((items) => {
                return (
                  <div className="box" key={items.count}>
                    <p>
                      <span> 0 of 10 </span>
                    </p>
                  </div>
                );
              })}
            </div>
          </p>
          <p>
            Moon Phase &nbsp; &nbsp; - &nbsp; &nbsp; &nbsp; &nbsp;
            <div className="dox">
              {Object.values(Data).map((items) => {
                return (
                  <div className="box" key={items.count}>
                    <p>Waning Crescent</p>
                  </div>
                );
              })}
            </div>
          </p>
        </div>
      </div>
    </div>
  );
}

export default bottom;
