import React from "react";
import Data from "../weather.json";

function top() {
  return (
    <div className="top-parent">
      <h2 className="top-div-1"> New York, NY, USA </h2>
      <div className="top-div-2">
        <div className="bottom-head">
          {Object.values(Data).map((items) => {
            return (
              <div className="box" key={items.count}>
                <h1>{items.results.channel.item.forecast[0].code} °C</h1>
              </div>
            );
          })}
        </div>
        <div>
          {Object.values(Data).map((items) => {
            return (
              <div className="box" key={items.count}>
                <p className="bottom-desc">
                  {items.results.channel.item.forecast[0].text}
                </p>
              </div>
            );
          })}
        </div>
        <p className="bottom-desc">
          {" "}
          Day <span> </span>
          <div className="dox">
            {Object.values(Data).map((items) => {
              return (
                <div className="box" key={items.count}>
                  <p>{items.results.channel.item.forecast[0].high}</p>
                </div>
              );
            })}
          </div>{" "}
          °C
          <span> </span>/<span> </span> Night<span> </span>
          <div className="dox">
            {Object.values(Data).map((items) => {
              return (
                <div className="box" key={items.count}>
                  <p>{items.results.channel.item.forecast[0].low}</p>
                </div>
              );
            })}
          </div>{" "}
          °C
        </p>
      </div>
    </div>
  );
}

export default top;
